abstract class Imovel {
  String endereco;
  double preco;

  Imovel
  (
      {
        required this.endereco,
        required this.preco
      }
  );
}
