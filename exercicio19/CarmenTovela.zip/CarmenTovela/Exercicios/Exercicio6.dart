import 'package:shared_preferences/shared_preferences.dart';

Future<String?> lerNome() async {
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  // Tenta ler a string. Retorna null se a chave não existir.
  String? nome = prefs.getString('nome_utilizador');
  if (nome != null) {
    print("Nome lido: $nome");
  } else {
    print("Nenhum nome encontrado.");
  }
  return nome;
}

// Como chamar a função:
void main() async {
  // Primeiro, vamos salvar um nome para ter algo para ler
  await salvarNome("Ana"); // Função do exercício anterior

  // Agora, vamos ler o nome
  String? nomeLido = await lerNome();
  if (nomeLido != null) {
    // Faz algo com o nomeLido
  }
}

// Função salvarNome (para o exemplo funcionar)
Future<void> salvarNome(String nome) async {
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.setString('nome_utilizador', nome);
  print("Nome '$nome' salvo com sucesso!");
}